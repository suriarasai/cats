package sg.edu.nus.cats.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sg.edu.nus.cats.model.User;

public interface UserRepository extends JpaRepository<User, String> {

	@Query("SELECT DISTINCT e2.name FROM User u, Employee e1, Employee e2 WHERE u.employeeId = e1.employeeId AND e1.managerId = e2.employeeId AND u.userId = :uid")
	List<String> findManagerNameByUID(@Param("uid") String uid);

	@Query("SELECT u FROM User u WHERE u.name = :un AND u.password = :pwd")
	Optional<User> findUserByNamePwd(@Param("un") String uname, @Param("pwd") String pwd);

}
